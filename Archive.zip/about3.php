<?php include('header.php');?>
<style>
.process-box {
    background: #fff;
    padding: 10px;
    border-radius: 15px;
    position: relative;
    box-shadow: 2px 2px 7px 0 #00000057;
}

.process-left:after {
    content: "";
    border-top: 15px solid #ffffff;
    border-bottom: 15px solid #ffffff;
    border-left: 15px solid #ffffff;
    border-right: 15px solid #ffffff;
    display: inline-grid;
    position: absolute;
    right: -15px;
    top: 42%;
    transform: rotate(45deg);
    box-shadow: 3px -2px 3px 0px #00000036;
    z-index: 1;
}

.process-right:after {
    content: "";
    border-top: 15px solid #ffffff00;
    border-bottom: 15px solid #ffffff;
    border-left: 15px solid #ffffff;
    border-right: 15px solid #ffffff00;
    display: inline-grid;
    position: absolute;
    left: -15px;
    top: 42%;
    transform: rotate(45deg);
    box-shadow: -1px 1px 3px 0px #0000001a;
    z-index: 1;
}

.process-step {
    /* background: #00BCD4; */
    background: #18cfdf;
    text-align: center;
    width: 85%;
    margin: 0 auto;
    color: #fff;
    height: 100%;
    padding-top: 10px;
    padding-bottom: 10px;
    position: relative;
    top: -26px;
    border-radius: 0px 0px 10px 10px;
    box-shadow: -6px 8px 0px 0px #00000014;
}

.process-last:before {
    display: none;
}

.process-box p {
    z-index: 9;
}

.process-step p {
    font-size: 20px;
}

.process-step h2 {
    font-size: 30px;
}

.process-step:after {
    content: "";
    border-top: 8px solid #04889800;
    border-bottom: 8px solid #048898;
    border-left: 8px solid #04889800;
    border-right: 8px solid #048898;
    display: inline-grid;
    position: absolute;
    left: -16px;
    top: 0;
}

.process-step:before {
    content: "";
    border-top: 8px solid #ff000000;
    border-bottom: 8px solid #048898;
    border-left: 8px solid #048898;
    border-right: 8px solid #ff000000;
    display: inline-grid;
    position: absolute;
    right: -16px;
    top: 0;
}

.process-line-l {
    background: white;
    height: 4px;
    position: absolute;
    width: 136px;
    right: -135px;
    /* top: 80px; */
    top: 50%;
    z-index: 9;
}

.process-line-r {
    background: white;
    height: 4px;
    position: absolute;
    width: 136px;
    left: -135px;
    /* top: 69px; */
    top: 50%;
    z-index: 9;
}

@media screen and (max-width: 600px) {
    .process-step:after {
        content: "";
        border-top: 8px solid #04889800;
        border-bottom: 8px solid #048898;
        border-left: 8px solid #04889800;
        border-right: 8px solid #048898;
        display: inline-grid;
        position: absolute;
        left: 0px;
        top: 0;
    }

    .process-step:before {
        content: "";
        border-top: 8px solid #ff000000;
        border-bottom: 8px solid #048898;
        border-left: 8px solid #048898;
        border-right: 8px solid #ff000000;
        display: inline-grid;
        position: absolute;
        right: 0px;
        top: 0;
    }

    .process-line-l {
        /* background: white; */
        background: #ffffff21;
        height: 4px;
        position: absolute;
        width: 100%;
        right: 0px;
        /* top: 64px; */
        top: 50%;
        z-index: 9;
    }

    .process-line-r {
        /* background: white; */
        background: #ffffff21;
        height: 4px;
        position: absolute;
        width: 100%;
        left: 0px;
        /* top: 63px; */
        top: 50%;
        z-index: 9;
    }

    .process-left:after {
        display: none !important;
        content: "";
        border-top: 15px solid #ffffff;
        border-bottom: 15px solid #ffffff;
        border-left: 15px solid #ffffff;
        border-right: 15px solid #ffffff;
        display: inline-grid;
        position: absolute;
        right: 0px;
        top: 42%;
        transform: rotate(45deg);
        box-shadow: 3px -2px 3px 0px #00000036;
        z-index: 1;
    }

    .process-right:after {
        display: none !important;
        content: "";
        border-top: 15px solid #ffffff00;
        border-bottom: 15px solid #ffffff;
        border-left: 15px solid #ffffff;
        border-right: 15px solid #ffffff00;
        display: inline-grid;
        position: absolute;
        left: 0px;
        top: 42%;
        transform: rotate(45deg);
        box-shadow: -1px 1px 3px 0px #0000001a;
        z-index: 1;
    }
}
</style>
<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<!-- Full Screen Search Start -->
<div class="modal fade" id="searchModal" tabindex="-1">
    <div class="modal-dialog modal-fullscreen">
        <div class="modal-content" style="background: rgba(9, 30, 62, .7);">
            <div class="modal-header border-0">
                <button type="button" class="btn bg-white btn-close" data-bs-dismiss="modal"
                    aria-label="Close"></button>
            </div>
            <div class="modal-body d-flex align-items-center justify-content-center">
                <div class="input-group" style="max-width: 600px;">
                    <input type="text" class="form-control bg-transparent border-primary p-3"
                        placeholder="Type search keyword">
                    <button class="btn btn-primary px-4"><i class="bi bi-search"></i></button>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Full Screen Search End -->


<!-- Hero Start -->
<div class="container-fluid bg-primary py-5 hero-header mb-5">
    <div class="row py-3">
        <div class="col-12 text-center">
            <h1 class="display-3 text-white animated zoomIn">About Us</h1>
            <a href="" class="h4 text-white">Home</a>
            <i class="far fa fa-angle-double-right text-white px-2"></i>
            <a href="" class="h4 text-white">About</a>
        </div>
    </div>
</div>
<!-- Hero End -->


<!-- About Start -->
<div class="container-fluid py-5 wow fadeInUp" data-wow-delay="0.1s">
    <div class="container">
        <div class="row g-5">
            <div class="col-lg-7">
            <div class="section-title mb-4">
                        <h5 class="position-relative d-inline-block text-primary text-uppercase">About Us</h5>
                        <h1 class="display-5 mb-0">Welcome To VK's Tutorial's</h1>
                    </div>
                    <h4 class="text-body fst-italic mb-4"> A New Educational Concept
                        Offering Powerful, Well Executed Pattern Of Modular Education
                         For CBSE, ICSE, SSC. 
                        </h4>
                    <p class="mb-4">We Offer Best Of The Best 
                        State-of-the-art Educational Experience For Your Full Academic Growth And Be Your Backbone Of Learning Where You Can Have Stress - Free Learning & Score Higher.</p>
                    <div class="row g-3">
                        <div class="col-sm-6 wow zoomIn" data-wow-delay="0.3s">
                            <h5 class="mb-3"><i class="fa fa-check-circle text-primary me-3"></i>Award Winning</h5>
                            <h5 class="mb-3"><i class="fa fa-check-circle text-primary me-3"></i>Professional Staff</h5>
                        </div>
                        <div class="col-sm-6 wow zoomIn" data-wow-delay="0.6s">
                            <h5 class="mb-3"><i class="fa fa-check-circle text-primary me-3"></i>24/7 Opened</h5>
                            <h5 class="mb-3"><i class="fa fa-check-circle text-primary me-3"></i>Fair Prices</h5>
                        </div>
                    </div>
                    <a href="appointment.html" class="btn btn-primary py-3 px-5 mt-4 wow zoomIn" data-wow-delay="0.6s">Know More</a>
            </div>
            <div class="col-lg-5" style="min-height: 500px;">
                <div class="position-relative h-100">
                    <img class="position-absolute w-100 h-100 rounded wow zoomIn" data-wow-delay="0.9s"
                        src="img/kids.jpg" style="object-fit: cover;">
                </div>
            </div>
        </div>
    </div>
</div>
<!-- About End -->


<section class="container-fluid position-relative py-5 m-0 wow fadeInUp our-blog bg-light">
    <div class="container work-process ">
        <div class="title mb-5 text-center">
            <h3>VK's Tutorial's</h3>
        </div>
        <!-- ============ step 1 =========== -->
        <div class="row my-5">
            <div class="col-md-8">
                <div class="process-box process-left" data-aos="fade-right" data-aos-duration="1000">
                    <div class="row py-3">
                        <div class="col-md-5">
                            <div class="process-step">

                                <h2 class="m-0 p-0">Question Paper</h2>
                            </div>
                        </div>
                        <div class="col-md-7">
                            <!-- <h5>What is Lorem Ipsum?</h5> -->
                            <p><small>All Exam Papers Are Set According To The Board Paper
                                    Pattern By Ex-board Teacher. Students Get Full Mock
                                    Practice Of Both Papers & Environment Of Exams As Well As Compete With The Best Of
                                    The Best In Inter</small></p>
                        </div>
                    </div>
                    <!-- <div class="process-line-l"></div> -->
                </div>
            </div>
            <!-- <div class="col-md-2"></div> -->
            <div class="col-md-4">
                <div class="process-point-right"></div>
            </div>
        </div>
        <!-- ============ step 2 =========== -->
        <div class="row my-5">

            <div class="col-md-4">
                <div class="process-point-left"></div>
            </div>
            <!-- <div class="col-md-2"></div> -->
            <div class="col-md-8">
                <div class="process-box process-right" data-aos="fade-left" data-aos-duration="1000">
                    <div class="row py-3">
                        <div class="col-md-5">
                            <div class="process-step">
                                <!-- <p class="m-0 p-0">Step</p> -->
                                <h2 class="m-0 p-0">Results</h2>
                            </div>
                        </div>
                        <div class="col-md-7">
                            <!-- <h5>What is Lorem Ipsum?</h5> -->
                            <p><small>All Papers Are Checked According To Model Answers
                                    Set By Actual Board Paper Moderators. Results Are
                                    Declared Both Online & Offline. </small></p>
                        </div>
                    </div>
                    <!-- <div class="process-line-r"></div> -->
                </div>
            </div>

        </div>
        <!-- ============ step 3 =========== -->
        <div class="row my-5">
            <div class="col-md-8">
                <div class="process-box process-left" data-aos="fade-right" data-aos-duration="1000">
                    <div class="row py-3">
                        <div class="col-md-5">
                            <div class="process-step">
                                <!-- <p class="m-0 p-0">Step</p> -->
                                <h2 class="m-0 p-0">Course Material</h2>
                            </div>
                        </div>
                        <div class="col-md-7">
                            <!-- <h5>What is Lorem Ipsum?</h5> -->
                            <p><small>All Study Material Is Highly Graded, Easy To
                                    Understand And Set To Give Full Marks. </small></p>
                        </div>
                    </div>
                    <!-- <div class="process-line-l"></div> -->
                </div>
            </div>
            <!-- <div class="col-md-2"></div> -->
            <div class="col-md-4">
                <div class="process-point-right"></div>
            </div>
        </div>
        <!-- ============ step 4 =========== -->
        <div class="row my-5">
            <div class="col-md-4">
                <div class="process-point-left"></div>
            </div>
            <!-- <div class="col-md-2"></div> -->
            <div class="col-md-8">
                <div class="process-box process-right" data-aos="fade-left" data-aos-duration="1000">
                    <div class="row py-3">
                        <div class="col-md-5">
                            <div class="process-step">
                                <!-- <p class="m-0 p-0">Step</p> -->
                                <h2 class="m-0 p-0"> Intensive Coaching</h2>
                            </div>
                        </div>
                        <div class="col-md-7">
                            <!-- <h5>What is Lorem Ipsum?</h5> -->
                            <p><small>
                                    Batches Are Segregated In Accordance To Performance And Special Coaching Is
                                    Imparted.
                                </small></p>
                        </div>
                    </div>
                    <!-- <div class="process-line-r"></div> -->
                </div>
            </div>


        </div>
        <!-- ============ step 3 =========== -->
        <div class="row my-5">
            <div class="col-md-8">
                <div class="process-box process-left" data-aos="fade-right" data-aos-duration="1000">
                    <div class="row py-3">
                        <div class="col-md-5">
                            <div class="process-step">
                                <!-- <p class="m-0 p-0">Step</p> -->
                                <h2 class="m-0 p-0">Parents Meeting</h2>
                            </div>
                        </div>
                        <div class="col-md-7">
                            <!-- <h5>What is Lorem Ipsum?</h5> -->
                            <p><small>Parents Are Regularly Updated On The StudentsParents Are Regularly Updated On The
                                    Students Performance As Well As Presented Reports And
                                    Improvisation Program Is Scheduled As Per The Need Of Student.</small></p>
                        </div>
                    </div>
                    <!-- <div class="process-line-l"></div> -->
                </div>
            </div>
            <!-- <div class="col-md-2"></div> -->
            <div class="col-md-4">
                <div class="process-point-right process-last"></div>
            </div>
        </div>
        <!-- ============ -->
        <!-- ============ step 4 =========== -->
        <div class="row my-5">
            <div class="col-md-4">
                <div class="process-point-left"></div>
            </div>
            <!-- <div class="col-md-2"></div> -->
            <div class="col-md-8">
                <div class="process-box process-right" data-aos="fade-left" data-aos-duration="1000">
                    <div class="row py-3">
                        <div class="col-md-5">
                            <div class="process-step">
                                <!-- <p class="m-0 p-0">Step</p> -->
                                <h2 class="m-0 p-0">Crareer Guidance</h2>
                            </div>
                        </div>
                        <div class="col-md-7">
                            <!-- <h5>What is Lorem Ipsum?</h5> -->
                            <p><small>Students Are Given Extensive Guidance And Motivation For Their Career By The
                                    Experts In The
                                    Commerce Industry.</small></p>
                        </div>
                    </div>
                    <!-- <div class="process-line-r"></div> -->
                </div>
            </div>


        </div>
        <!-- ============ step 3 =========== -->
        <div class="row my-5">
            <div class="col-md-8">
                <div class="process-box" data-aos="fade-right" data-aos-duration="1000">
                    <div class="row py-3">
                        <div class="col-md-5">
                            <div class="process-step">
                                <!-- <p class="m-0 p-0">Step</p> -->
                                <h2 class="m-0 p-0">Felicitation</h2>
                            </div>
                        </div>
                        <div class="col-md-7">
                            <!-- <h5>What is Lorem Ipsum?</h5> -->
                            <p><small>Top Scorers And Performers As Well As Winners Of Kbc Contest Are Felicitated With
                                    Certificates/ Medals/
                                    Trophies.</small></p>
                        </div>
                    </div>
                    <!-- <div class="process-line-l"></div> -->
                </div>
            </div>
            <!-- <div class="col-md-2"></div> -->
            <div class="col-md-4">
                <div class="process-point-right process-last"></div>
            </div>
        </div>
        <!-- ============ -->
    </div>
</section>
<script>
AOS.init();
</script>

<?php include('footer.php');?>