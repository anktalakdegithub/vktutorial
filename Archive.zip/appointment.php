<?php include('header.php');?>
<!-- Full Screen Search Start -->
<div class="modal fade" id="searchModal" tabindex="-1">
    <div class="modal-dialog modal-fullscreen">
        <div class="modal-content" style="background: rgba(9, 30, 62, .7);">
            <div class="modal-header border-0">
                <button type="button" class="btn bg-white btn-close" data-bs-dismiss="modal"
                    aria-label="Close"></button>
            </div>
            <div class="modal-body d-flex align-items-center justify-content-center">
                <div class="input-group" style="max-width: 600px;">
                    <input type="text" class="form-control bg-transparent border-primary p-3"
                        placeholder="Type search keyword">
                    <button class="btn btn-primary px-4"><i class="bi bi-search"></i></button>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Full Screen Search End -->


<!-- Hero Start -->
<div class="container-fluid bg-primary py-5 hero-header mb-5">
    <div class="row py-3">
        <div class="col-12 text-center">
            <h1 class="display-3 text-white animated zoomIn">Enquire Now</h1>
            <a href="" class="h4 text-white">Home</a>
            <i class="far fa fa-angle-double-right text-white px-2"></i>
            <a href="" class="h4 text-white">Enquire Now</a>
        </div>
    </div>
</div>
<!-- Hero End -->


<!-- Appointment Start -->
<div class="container-fluid mb-5 pb-5 wow fadeInUp" data-wow-delay="0.1s" style="margin-top: 90px;">
    <div class="container">
        <div class="row gx-5">
            <div class="col-lg-6 ">
                <div class="">
                    <!-- <h1 class="display-5 text-dark mb-4">We Are A Certified and Award Winning Dental Clinic You Can Trust</h1> -->
                    <!-- <p class="text-dark mb-0">Eirmod sed tempor lorem ut dolores. Aliquyam sit sadipscing kasd ipsum. Dolor ea et dolore et at sea ea at dolor, justo ipsum duo rebum sea invidunt voluptua. Eos vero eos vero ea et dolore eirmod et. Dolores diam duo invidunt lorem. Elitr ut dolores magna sit. Sea dolore sanctus sed et. Takimata takimata sanctus sed.</p> -->
                    <img src="img/vkbanner.png" alt="vk banner">
                </div>
            </div>
            <div class="col-lg-6">
                <div class="enquire h-100 d-flex flex-column justify-content-center text-center p-5 wow zoomIn"
                    data-wow-delay="0.6s">
                    <h1 class="text-dark mb-4">Enquire Now</h1>
                    <form  method="POST">
                        <div class="row g-3">

                            <div class="col-12 col-sm-6">
                                <input type="text"  name="name" id="name" class="form-control bg-light border-0" placeholder="Your Name"
                                    style="height: 55px;">
                            </div>
                            <div class="col-12 col-sm-6">
                                <input type="email" name="email" id="email" class="form-control bg-light border-0" placeholder="Your Email"
                                    style="height: 55px;">
                            </div>
                            <div class="col-12 col-sm-6">

                                <select class="form-select bg-light border-0" name="class" style="height: 55px;">
                                    <option selected>Select a Class</option>
                                    <option value="v">v</option>
                                    <option value="VI">VI</option>
                                    <option value="VII">VII</option>
                                    <option value="VIII">VIII</option>
                                    <option value="IX">IX</option>
                                    <option value="X">X</option>
                                    <option value="XI (Commerce)">XI (Commerce)</option>
                                    <option value="XII (Commerce)">XII (Commerce)</option>
                                </select>
                            </div>
                            <div class="col-12 col-sm-6">
                                <select class="form-select bg-light border-0" name="grade" style="height: 55px;">
                                    <option selected>Select Grade</option>
                                    <option value="CBSC">CBSC</option>
                                    <option value="SSC">SSC</option>
                                    <option value="ICSE">ICSE</option>
                                </select>
                            </div>
                            <div class="col-12 col-sm-12">
                                <input type="tel"  name="contactnum" id="contactnum" class="form-control bg-light border-0" placeholder="Contact Number"
                                    style="height: 55px;">
                            </div>
                            <div class="col-12">
                                <!-- <button class="btn btn-dark w-100 py-3" type="submit">Make Appointment</button> -->
                                <button type="submit" name="submit" class="btn btn-dark w-100 py-3" id="butaddresult">Make Appointment</button>
                         					  <div id="msg"></div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Appointment End -->


<!-- Newsletter Start --
    <div class="container-fluid position-relative pt-5 wow fadeInUp" data-wow-delay="0.1s" style="z-index: 1;">
        <div class="container">
            <div class="bg-primary p-5">
                <form class="mx-auto" style="max-width: 600px;">
                    <div class="input-group">
                        <input type="text" class="form-control border-white p-3" placeholder="Your Email">
                        <button class="btn btn-dark px-4">Sign Up</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    -- Newsletter End -->


<!-- Footer Start -->
<?php include('footer.php');?>

<script>
$('#butaddresult').on('click', function()
{
  var name = $('#name').val();
		var email = $('#email').val();
        var class = $('#class').val();
        var grade = $('#grade').val();
    var contactnum = $('#contactnum').val();

    $.ajax({
        url:"savedata.php",
        data: {'name': name,'email':email,'class':class,'grade':grade,'contactnum':contactnum},
        dataType: "json",
        type: "post",
        success: function(data) {
           
               debugger;
          if(data.code=="404"){
                    $('#msg').html('<div class="alert alert-danger mt-3" role="alert">'+data.msg+'</div>');
                }
                else{
                    $('#msg').html('<div class="alert alert-success mt-3" role="alert">'+data.msg+'</div>');
                    // purchase_product();
                    // window.location.href="contact.php";					

                }
          
        }
    });
});

</script>