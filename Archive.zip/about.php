<?php include('header.php');?>
<style>
.imga {
    height: 235px;
    width: 235px;
    /* height: 205px;
    width: 205px; */
    /* border-radius: 140px;
    border: 1px solid black; */
}
.imgr{
    border-radius: 113px;
}

.cardjustify {
    text-align: justify;
}
</style>
<!-- Hero Start -->
<div class="container-fluid bg-primary py-5 hero-header mb-5">
    <div class="row py-3">
        <div class="col-12 text-center">
            <h1 class="display-3 text-white animated zoomIn">About Us</h1>
            <a href="" class="h4 text-white">Home</a>
            <i class="far fa fa-angle-double-right text-white px-2"></i>
            <a href="" class="h4 text-white">About</a>
        </div>
    </div>
</div>
<!-- Hero End -->



<div class="container-fluid py-5 wow fadeInUp" data-wow-delay="0.1s">

    <div class="container">
        <div class="row g-5">
            <div class="col-lg-7">
                <div class="section-title mb-4">
                    <h5 class="position-relative d-inline-block text-primary text-uppercase">About Us</h5>
                    <!-- <h1 class="display-5 mb-0">Welcome To VK's Tutorial's</h1> -->
                </div>
                <h4 class="text-dark mb-4"> A new educational concept
                    offering powerful, Well executed pattern of modular education
                    for CBSE, ICSE, SSC.
                </h4>
                <div class="card wow slideInUp cardslide text-dark p-3">
                    <h4 class="text-dark">
                        <img src="img/icon/target.png" class="px-2" alt="mission">
                        <!-- <i class="fa fa-check-circle" style="color: #06a3da;" aria-hidden="true"></i> -->
                        Our Mission
                    </h4>
                    <p class="text-dark mb-4" style="text-align: inherit;padding-left: 11px;"> Our mission is to provide professional quality state-Of-the-art education
                        to
                        maximum students
                        all over the state with same content and expertise as provided to elite students.
                    </p>
                </div>
                <div class="card wow slideInUp cardslide text-dark p-3 mt-3">
                <h4 class="text-dark">
                    <!-- <i class="fa fa-check-circle" style="color: #06a3da;" aria-hidden="true"></i> -->
                    <img src="img/icon/vision.png" class="px-2" alt="vision">
                    Our Vision
                </h4>
                <p class="mb-4" style="text-align: inherit;padding-left: 11px;">To become the number one institue in the heart of students and parents.</p>
                </div>

               
                <!-- <div class="row mt-2">
                    <div class="col-sm-6">
                        <h5 class="mb-3"><i class="fa fa-check-circle text-primary me-3"></i>Finest Teaching</h5>
                        <h5 class="mb-3"><i class="fa fa-check-circle text-primary me-3"></i>Finest Reporting</h5>
                    </div>
                    <div class="col-sm-6">
                        <h5 class="mb-3"><i class="fa fa-check-circle text-primary me-3"></i>Finest Testing</h5>
                        <h5 class="mb-3"><i class="fa fa-check-circle text-primary me-3"></i>Finest Growth</h5>
                    </div>
                </div> -->
                <!-- <h5 class="mb-3"><i class="fa fa-check-circle text-primary me-3"></i>State of the art Digital Classroom
                </h5>
                <h5 class="mb-3"><i class="fa fa-check-circle text-primary me-3"></i>State of the art Digital Education
                </h5>
                <h5 class="mb-3"><i class="fa fa-check-circle text-primary me-3"></i>State of the art Teaching Modules
                </h5>
                <h5 class="mb-3"><i class="fa fa-check-circle text-primary me-3"></i>State of the art Testing &
                    Reporting</h5> -->


                <!-- <button class="btn btn-primary py-3 px-5 mt-4 wow zoomIn knowmore">Know
                    More</button> -->

            </div>
            <div class="col-lg-5" style="min-height: 300px;">
                <div class="position-relative h-100">
                    <img class="position-absolute w-100 h-100 rounded wow zoomIn" data-wow-delay="0.9s"
                        src="img/aboutm.jpg" style="object-fit: cover;">
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row g-5">
            <div class="section-title text-center mb-4 pt-3">
                <!-- <h5 class="position-relative d-inline-block text-primary text-uppercase text-center pt-5">Our Directions</h5> -->
                <h1 class="display-5 mb-0 pt-5">Our Directors</h1>
            </div>
            <!-- <h1 class="display-5 mb-2 pt-4 text-center">Our Directions</h1> -->
            <div class="col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                <div class="card py-3 bg-light h-100">
                   
                    <center>
                    <div class="imga">
                        <img src="img/Ravindra22.png" class="card-img-top imgr" alt="director">
                        </div>
                    </center>
                  
                    <div class="card-body team-text position-relative  text-center rounded-bottom p-4 pt-5">
                        <h4 class="card-title text-center">Prof. Shree. Ravindra S. Kokate. (Managing Director)</h4>
                        <p class="card-text cardjustify">A legendary personality in the field of education with over
                            26 years of qualitative exprience in teaching & administration at
                            Maharashtra's Leading institute <b>'Kokate Coaching classes'</b> an <b>ISO 9001-2015</b>
                            certified class, which was a boon in the field of education from year 2003 boasting
                            more than <b>7 branches</b> and inspired and built career of more than <b>13,000
                                students</b> till date. which includes students from all major boards in Maharashtra
                            like
                            State Board, CBSE Board & ICSE Board,
                            <a class="knowmore" style="cursor: pointer;">Read More</a>
                        </p>
                        <div class="kmshow">
                            <p class="card-text cardjustify">
                                Having rich experience in the entire gamut of institute administration inclusive of
                                curriculum planning teacher training, organizing MPSC/UPSC mock seminars for
                                students,
                                Conducting SSC & HSC Board Test series & development of Digitalization in Education
                                field.
                                <br> His greatest strengths which helped him to achieve a successful CEO position in the
                                institute are his logical and critical thinking. Ability to solve problems
                                quickly & efficiently, excellent communication skills and management ability.

                            </p>
                            <h6 class="text-body fst-italic mb-4 cardjustify"> Well versed with modern technology in
                                educational practices
                                and offering years of
                                achievement and experience in developing a student-centric environment, geared towards
                                maximizing learning experiences.</h6>
                            <a class="knowless" style="cursor: pointer;">Read Less</a>
                        </div>
                        <h5>We believe he performs five key practices</h5>
                        <div class="row">
                            <div class="col-md-6">
                                <p class="text-start"><i class="fa fa-arrow-right" aria-hidden="true"></i> Shaping a
                                    vision of academic success for all students.</p>
                                <p class="text-start"><i class="fa fa-arrow-right" aria-hidden="true"></i> Creating a
                                    climate hospitable to education </p>
                                <p class="text-start"><i class="fa fa-arrow-right" aria-hidden="true"></i> Cultivating
                                    leadership in others</p>

                            </div>
                            <div class="col-md-6">
                                <p class="text-start"><i class="fa fa-arrow-right" aria-hidden="true"></i> Improving
                                    instructions</p>
                                <p class="text-start"><i class="fa fa-arrow-right" aria-hidden="true"></i> Adopting
                                    technological development in Education</p>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                <div class="card py-3 bg-light h-100">
                    
                <center>
                    <div class="imga">
                        <img src="img/prakash22.png" class="card-img-top imgr" alt="director">
                        </div>
                    </center>
                    <!-- <center>
                        <img src="img/prakash2.png" class="card-img-top " alt="...">
                    </center> -->
                    <div class="card-body team-text position-relative  text-center rounded-bottom p-4 pt-5">
                        <h4 class="card-title text-center">Prof. Shree. Prakash A. Patil.(Director)</h4>
                        <p class="card-text cardjustify">Respected prof. shree Prakash Patil sir is a multitalented
                            personality in various fields like Education, Banking & social work. He has been working in
                            Education field for more than <b>32 years</b> running smoothly a Well-Known Institute in
                            Thane by the name of <b>'Vidhyashree Classes'</b> educating nearly <b>10 to 12
                                thousand</b> students all over <b>Thane and vicinity</b>. Also started <b>'Little Buds
                                Pre-school'</b> to cater early education with good ordination in small children.
                            <b>Shree Prakash Patil</b> sir is reffered as <b>'Guruvarya'</b> by the peoples of Thane for
                            their extra-ordinary and long lasting Contribution in the field of education. He is also
                            very active in social work practices for betterment of needy people who are deprived of
                            minimum nessecities of life.</br></br>
                            <b><span class="text-body fst-italic mb-4"> His main aim to provide the best education
                                    to all
                                    the students of all Boards & Mediums in offordable cost in digitalized
                                    manner</span></b>
                        </p>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <!-- <div class="container-fluid py-5 wow fadeInUp" data-wow-delay="0.1s">
        <div class="text-center mb-4">

            <h1 class="display-5 mb-0">Distinguishing Characteristics</h1>
            <h5 class="position-relative d-inline-block text-primary text-uppercase text-center">(We are different..!)
            </h5>
        </div>
        <div class="row my-3">
            <div class="col-md-4">
                <div class="card h-100 wow slideInUp cardslide bg-light text-dark py-2">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-1">
                                <img src="img/icon/checklist.png" alt="Question Paper">
                            </div>
                            <div class="col-md-11 ">
                                <h5 class="m-md-3"> Question Paper</h5>
                            </div>
                        </div>

                        <p> All exam papers are set according to the board paper pattern by Ex-board teacher. Students
                            get full mock practice of both papers
                            & environment of exams as well as compete with the best of the best in inter district exams.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card h-100 wow slideInUp cardslide bg-light text-dark py-2">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-1">
                                <img src="img/icon/results.png" alt="">
                            </div>
                            <div class="col-md-11">
                                <h5 class="m-md-3"> Results</h5>
                            </div>
                        </div>

                        <p> All Papers are checked according to
                            model answers set by actual board paper moderators. results are declared both online &
                            offline.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card h-100 wow slideInUp cardslide bg-light text-dark py-2">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-1">
                                <img src="img/icon/online-learning.png" alt="">
                            </div>
                            <div class="col-md-11">
                                <h5 class="m-md-3"> Course Material</h5>
                            </div>
                        </div>

                        <p> All study material is
                            highly graded, Easy to understand and set to give full marks.</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="row my-3">
            <div class="col-md-4">
                <div class="card h-100 wow slideInUp cardslide bg-light text-dark py-2">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-1">
                                <img src="img/icon/instructor.png" alt="">
                            </div>
                            <div class="col-md-11">
                                <h5 class="m-md-3"> Intensive Coaching</h5>
                            </div>
                        </div>

                        <p> Batches are segregated in accordance to performance and special coaching is imparted.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card h-100 wow slideInUp cardslide bg-light text-dark py-2">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-1">
                                <img src="img/icon/team.png" alt="">
                            </div>
                            <div class="col-md-11">
                                <h5 class="m-md-3"> Parents Meeting</h5>
                                </h5>
                            </div>
                        </div>

                        <p> Parents are regularly updated on the students
                            performance as well as presented
                            reports and improvisation program is scheduled as per the need of student.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card h-100 wow slideInUp cardslide bg-light text-dark py-2">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-1">
                                <img src="img/icon/careerpath.png" alt="">
                            </div>
                            <div class="col-md-11">
                                <h5 class="m-md-3"> Career Guidance</h5>
                                </h5>
                            </div>
                        </div>
                        <p> Students are given
                            extensive guidance and motivation for their career by the experts in the commerce industry.
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <div class="row my-3">
            <div class="col-md-2"></div>
            <div class="col-md-4">
                <div class="card h-100 wow slideInUp cardslide bg-light text-dark py-2">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-1">
                                <img src="img/icon/bouquet.png" alt="">
                            </div>
                            <div class="col-md-11">
                                <h5 class="m-md-3"> Felicitation</h5>
                                </h5>
                            </div>
                        </div>
                      
                        <p> Top Scorers And Performers As
                            Well As Winners Of Kbc Contest Are Felicitated With Certificates/ Medals/ Trophies.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card h-100 wow slideInUp cardslide bg-light text-dark py-2">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-1">
                                <img src="img/icon/course.png" alt="">
                            </div>
                            <div class="col-md-11">
                                <h5 class="m-md-3"> Course Module</h5>
                                </h5>
                            </div>
                        </div>
                     
                        <table class="table">
                            <tbody>
                                <tr>
                                    <th scope="row">V to VII</th>
                                    <td>CBSE</td>
                                    <td>ICSE</td>
                                    <td>SSC</td>
                                </tr>
                                <tr>
                                    <th scope="row">VIII to X</th>
                                    <td>CBSE</td>
                                    <td>ICSE</td>
                                    <td>SSC</td>
                                </tr>
                                <tr>
                                    <th scope="row">XI to XII Commerce</th>
                                    <td>CBSE</td>
                                    <td>ICSE</td>
                                    <td>SSC</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-md-2"></div>
        </div>

    </div> -->
</div>
<!-- About Start -->
<div class="container-fluid py-5">

</div>

<!-- About End -->
<!-- 
<section class="timeline">
    <ul class="py-5 my-5">
        <li>
            <div>
                <time><i class="fa fa-paper-plane" aria-hidden="true"></i> Question Paper</time> All Exam Papers Are Set
                According To The Board Paper Pattern By Ex-board Teacher. Students Get Full Mock Practice Of Both Papers
                & Environment Of Exams As Well As Compete With The Best Of The Best In Inter
            </div>
        </li>
        <li>
            <div>
                <time><i class="fa fa-trophy" aria-hidden="true"></i> Results</time> All Papers Are Checked According To
                Model Answers Set By Actual Board Paper Moderators. Results Are Declared Both Online & Offline.
            </div>
        </li>
        <li>
            <div>
                <time><i class="fa fa-th-list" aria-hidden="true"></i> Course Material</time> All Study Material Is
                Highly Graded, Easy To Understand And Set To Give Full Marks.
            </div>
        </li>
        <li>
            <div>
                <time><i class="fa fa-clipboard" aria-hidden="true"></i> Intensive Coaching</time> Batches Are
                Segregated In Accordance To Performance And Special Coaching Is Imparted.
            </div>
        </li>
        <li>
            <div>
                <time><i class="fa fa-users" aria-hidden="true"></i> Parents Meeting</time> Parents Are Regularly
                Updated On The StudentsParents Are Regularly Updated On The Students Performance As Well As Presented
                Reports And Improvisation Program Is Scheduled As Per The Need Of Student.
            </div>
        </li>
        <li>
            <div>
                <time><i class="fa fa-list-alt" aria-hidden="true"></i> Crareer Guidance</time> Students Are Given
                Extensive Guidance And Motivation For Their Career By The Experts In The Commerce Industry.
            </div>
        </li>
        <li>
            <div>
                <time><i class="fa fa-star" aria-hidden="true"></i> Felicitation</time> Top Scorers And Performers As
                Well As Winners Of Kbc Contest Are Felicitated With Certificates/ Medals/ Trophies.
            </div>
        </li>

    </ul>
</section> -->


<script>
(function() {
    "use strict";

    // define variables
    var items = document.querySelectorAll(".timeline li");

    // check if an element is in viewport
    // http://stackoverflow.com/questions/123999/how-to-tell-if-a-dom-element-is-visible-in-the-current-viewport
    function isElementInViewport(el) {
        var rect = el.getBoundingClientRect();
        return (
            rect.top >= 0 &&
            rect.left >= 0 &&
            rect.bottom <=
            (window.innerHeight || document.documentElement.clientHeight) &&
            rect.right <= (window.innerWidth || document.documentElement.clientWidth)
        );
    }

    function callbackFunc() {
        for (var i = 0; i < items.length; i++) {
            if (isElementInViewport(items[i])) {
                items[i].classList.add("in-view");
            }
        }
    }

    // listen for events
    window.addEventListener("load", callbackFunc);
    window.addEventListener("resize", callbackFunc);
    window.addEventListener("scroll", callbackFunc);
})();
</script>

<?php include('footer.php');?>
<script>
$(".kmshow").hide();
$(".knowmore").click(function() {
    $(".kmshow").show();
    $(".knowmore").hide();
});

$(".knowless").click(function() {
    $(".knowmore").show();
    $(".kmshow").hide();
});
</script>